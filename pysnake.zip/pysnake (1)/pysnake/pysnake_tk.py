import tkinter as tk
import random

WIDTH, HEIGHT = 640, 480
BLOCK = 20
FPS = 10  # moves per second


class SnakeGame(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('PySnake (tkinter)')
        self.resizable(False, False)
        self.canvas = tk.Canvas(self, width=WIDTH, height=HEIGHT, bg='black')
        self.canvas.pack()

        self.direction = (0, -BLOCK)
        self.snake = [(WIDTH // 2, HEIGHT // 2)]
        self.food = self.random_food()
        self.score = 0
        self.game_over = False

        self.bind_all('<Key>', self.on_key)
        self.after_id = None
        self.draw()
        self.loop()

    def random_food(self):
        cols = WIDTH // BLOCK
        rows = HEIGHT // BLOCK
        while True:
            x = random.randrange(0, cols) * BLOCK
            y = random.randrange(0, rows) * BLOCK
            if (x, y) not in self.snake:
                return x, y

    def on_key(self, event):
        k = event.keysym
        dx, dy = self.direction
        if k == 'Up' and (dx, dy) != (0, BLOCK):
            self.direction = (0, -BLOCK)
        elif k == 'Down' and (dx, dy) != (0, -BLOCK):
            self.direction = (0, BLOCK)
        elif k == 'Left' and (dx, dy) != (BLOCK, 0):
            self.direction = (-BLOCK, 0)
        elif k == 'Right' and (dx, dy) != (-BLOCK, 0):
            self.direction = (BLOCK, 0)
        elif k in ('r', 'R') and self.game_over:
            self.restart()
        elif k in ('q', 'Q') and self.game_over:
            self.quit()

    def loop(self):
        if not self.game_over:
            head_x, head_y = self.snake[0]
            dx, dy = self.direction
            new_head = (head_x + dx, head_y + dy)

            if (
                new_head[0] < 0
                or new_head[0] >= WIDTH
                or new_head[1] < 0
                or new_head[1] >= HEIGHT
                or new_head in self.snake
            ):
                self.game_over = True
            else:
                self.snake.insert(0, new_head)
                if new_head == self.food:
                    self.score += 1
                    self.food = self.random_food()
                else:
                    self.snake.pop()

        self.draw()
        delay = int(1000 / FPS)
        self.after_id = self.after(delay, self.loop)

    def draw(self):
        self.canvas.delete('all')
        for x, y in self.snake:
            self.canvas.create_rectangle(x, y, x + BLOCK, y + BLOCK, fill='green', outline='')
        fx, fy = self.food
        self.canvas.create_rectangle(fx, fy, fx + BLOCK, fy + BLOCK, fill='red', outline='')
        self.canvas.create_text(60, 20, text=f'Score: {self.score}', fill='white', font=('Arial', 14))

        if self.game_over:
            self.canvas.create_text(WIDTH//2, HEIGHT//2 - 20, text='Game Over', fill='white', font=('Arial', 32))
            self.canvas.create_text(WIDTH//2, HEIGHT//2 + 20, text='Press R to Restart or Q to Quit', fill='gray', font=('Arial', 14))

    def restart(self):
        self.direction = (0, -BLOCK)
        self.snake = [(WIDTH // 2, HEIGHT // 2)]
        self.food = self.random_food()
        self.score = 0
        self.game_over = False


def main():
    app = SnakeGame()
    app.mainloop()


if __name__ == '__main__':
    main()
