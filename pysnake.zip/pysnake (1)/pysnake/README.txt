** COPIED FROM GITHUB REPO **

# pysnake
A Python adaption of the hit game "Snake"

# CONTROLS
Left arrowkey - Move left
Right arrowkey - Move right
Up arrowkey - Move up
Down arrowkey - Move down
Q - Quit
R - Restart
